// Single-owner authentication. Credentials stay in managed Worker secrets.
export type PasswordEnv={LOGIN_PASSWORD?:string;LIMITS?:{idFromName(s:string):unknown;get(id:unknown):{fetch(r:Request):Promise<Response>}}};
const enc=new TextEncoder();
const cookieName='__Host-lifeflow';
const fail=(message:string,status:number)=>new Response(message,{status,headers:{'Cache-Control':'no-store','Content-Type':'text/plain;charset=utf-8'}});
const b64=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const unb64=(s:string)=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
function secret(env:PasswordEnv){const s=env.LOGIN_PASSWORD;if(!s||s.length<24||s.length>256)throw Error('not configured');return s}
async function key(env:PasswordEnv){return crypto.subtle.importKey('raw',enc.encode('lifeflow-session-v1\0'+secret(env)),{name:'HMAC',hash:'SHA-256'},false,['sign','verify'])}
export async function passwordSession(req:Request,env:PasswordEnv,now=Date.now()){
 const token=req.headers.get('Cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1);
 if(!token||token.length>1000)throw Error('auth');const [payload,signature,extra]=token.split('.');if(extra||!payload||!signature)throw Error('auth');
 if(!await crypto.subtle.verify('HMAC',await key(env),unb64(signature),enc.encode(payload)))throw Error('auth');
 const data=JSON.parse(new TextDecoder().decode(unb64(payload)));
 if(data.sub!=='owner'||!Number.isInteger(data.exp)||!Number.isInteger(data.iat)||data.iat>now||data.exp<=now||data.exp-data.iat!==3600000)throw Error('auth');return 'owner';
}
async function equalPassword(provided:string,env:PasswordEnv){
 // Fixed-size digests, with WebCrypto's signature verification doing the comparison.
 const k=await crypto.subtle.importKey('raw',enc.encode(secret(env)),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);
 const signature=await crypto.subtle.sign('HMAC',k,enc.encode(provided));return crypto.subtle.verify('HMAC',k,signature,enc.encode(secret(env)));
}
export function loginPage(){return new Response(`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>دخول LifeFlow</title><h1>دخول LifeFlow</h1><p>أدخل كلمة الدخول الخاصة التي حفظتها في Cloudflare. لا تدخل مفتاح Gemini هنا.</p><form method="post" action="/login"><label>كلمة الدخول <input name="password" type="password" autocomplete="current-password" required minlength="24" maxlength="256"></label><button>دخول</button></form></html>`,{headers:{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-store','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",'X-Content-Type-Options':'nosniff'}})}
export async function passwordRoutes(req:Request,env:PasswordEnv):Promise<Response|null>{
 const u=new URL(req.url);if(u.pathname!=='/login'&&u.pathname!=='/logout')return null;
 if(u.protocol!=='https:')return fail('HTTPS مطلوب',400);
 if(req.method==='GET'&&u.pathname==='/login')return loginPage();
 if(req.method!=='POST'||req.headers.get('Origin')!==u.origin)return fail('طلب غير مسموح',403);
 if(u.pathname==='/logout')return new Response(null,{status:303,headers:{Location:'/login','Cache-Control':'no-store','Set-Cookie':`${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`}});
 if(!req.headers.get('Content-Type')?.startsWith('application/x-www-form-urlencoded'))return fail('صيغة غير صالحة',400);
 try{
  secret(env);if(!env.LIMITS)throw Error('no limiter');
  // A single global login budget also prevents distributed guessing; failed attempts use no Gemini quota.
  const limit=env.LIMITS.get(env.LIMITS.idFromName('password-login'));
  if(!(await limit.fetch(new Request('https://limits/login'))).ok)return fail('محاولات دخول كثيرة. حاول لاحقًا.',429);
  const reader=req.body?.getReader();if(!reader)return fail('طلب فارغ',400);let size=0,text='';const decoder=new TextDecoder();
  try{for(;;){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>2048)return fail('الطلب أكبر من المسموح',413);text+=decoder.decode(x.value,{stream:true})}text+=decoder.decode()}finally{await reader.cancel()}
  const params=new URLSearchParams(text);let count=0;params.forEach(()=>count++);if(count!==1||!params.has('password'))return fail('صيغة غير صالحة',400);const password=params.get('password')!;
  if(password.length<24||password.length>256||!await equalPassword(password,env))return fail('بيانات الدخول غير صحيحة. ارجع وحاول مجددًا.',401);
  const now=Date.now();const payload=b64(enc.encode(JSON.stringify({sub:'owner',iat:now,exp:now+3600000,nonce:crypto.randomUUID()})));
  const signature=b64(new Uint8Array(await crypto.subtle.sign('HMAC',await key(env),enc.encode(payload))));
  return new Response(null,{status:303,headers:{Location:'/bridge','Cache-Control':'no-store','Set-Cookie':`${cookieName}=${payload}.${signature}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=3600`}});
 }catch{return fail('إعداد حماية الدخول غير مكتمل؛ لم يتم الاتصال بـGemini.',503)}
}
