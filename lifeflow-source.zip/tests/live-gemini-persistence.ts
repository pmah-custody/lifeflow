import {IndexedRepository} from '../src/local/storage';
import {CommandService} from '../src/local/executor';
import {validateInterpretation} from '../src/local/ai-contract';
const repo=new IndexedRepository('lifeflow-gemini-live-result-20261101-v2');
const title='شراء مقاضي بكرا قبل الظهر';
const out=document.querySelector('#result')!;
try{
 const response=await fetch('/qa/live-gemini-result.json').then(r=>r.json());
 const draft=validateInterpretation(response.result,title);
 let store=await repo.load();
 if(!store.records.length){
  const svc=new CommandService(repo,()=>new Date('2026-11-01T10:00:00+03:00'),async()=>draft);
  store=(await svc.submitSmart(title)).store;
  if(store.commands.at(-1)?.status!=='completed'||store.records.length!==1)throw Error('command not saved');
  sessionStorage.setItem('lifeflow-live-gemini-id',store.records[0].id);
  out.textContent='SAVED LIVE GEMINI RESULT: '+JSON.stringify(store.records[0]);
 }else{
  const r=store.records[0];
  if(r.id!==sessionStorage.getItem('lifeflow-live-gemini-id')||r.kind!=='task'||r.category!=='personal'||r.title!==title||r.date!=='2026-11-02'||r.time!==undefined||r.content!=='الفترة المطلوبة: قبل الظهر')throw Error('persistence mismatch');
  out.textContent='PASS AFTER RELOAD: '+JSON.stringify(r);
 }
}catch(e){out.textContent='FAIL: '+e}
