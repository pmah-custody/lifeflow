import assert from 'node:assert/strict';
import fs from 'node:fs';
import {safeInput,clean,validateInterpretation,type Interpretation} from '../src/local/ai-contract';
import {CommandService} from '../src/local/executor';
import {MemoryRepository} from '../src/local/storage';
import worker,{UserLimits} from '../worker/src/index';
const now=new Date('2026-10-29T22:00:00+03:00');
const fixtures:[string,Partial<Interpretation>][]=[
 ['اجتماع بكرا الساعه 10 زوم',{intent:'event',date:'tomorrow',clarification:'time',proposedActions:'clarify'}],
 ['ارسال ايميل لشؤون الموظفين الصباح',{category:'work',period:'morning',clarification:'date',proposedActions:'clarify'}],
 ['شراء مقاضي بكرا قبل الظهر',{date:'tomorrow',period:'beforeNoon'}],
 ['اجتماع اليوم الساعه 14 زوم',{intent:'event',date:'today',time:'14:00'}],
 ['موعد بكرا الساعه 8 صباحا',{intent:'event',date:'tomorrow',time:'08:00',period:'morning'}],
 ['اجتماع بعد بكرا الساعه 10 مساء',{intent:'event',date:'afterTomorrow',time:'22:00',period:'evening'}],
 ['زيارة الطبيب بكرا',{date:'tomorrow'}],['مشي اليوم',{date:'today'}],['تنظيف البيت',{}],['قراءة كتاب',{}],
 ['راجع تقرير العمل اليوم',{category:'work',date:'today'}],['جهز ايميل للموظفين بكرا',{category:'work',date:'tomorrow'}],
 ['عاجل ارسال ايميل اليوم',{category:'work',date:'today',priority:'urgent'}],['ضروري تنظيف البيت',{priority:'urgent'}],
 ['بيض وكندر',{intent:'grocery'}],['حليب وخبز',{intent:'grocery'}],['رز وسكر',{intent:'grocery'}],['تفاح وموز',{intent:'grocery'}],
 ['شراء مقاضي غدا قبل الظهر',{date:'tomorrow',period:'beforeNoon'}],['مشي بكرا العصر',{date:'tomorrow',period:'afternoon'}],
 ['قراءة كتاب اليوم المساء',{date:'today',period:'evening'}],['مشي الصباح',{period:'morning',clarification:'date',proposedActions:'clarify'}],
 ['لا تضيف اجتماع بكرا',{intent:'event',date:'tomorrow',clarification:'content',proposedActions:'clarify'}],
 ['لاترسل ايميل اليوم',{category:'work',date:'today',clarification:'content',proposedActions:'clarify'}],
 ['مو اجتماع اليوم',{intent:'event',date:'today',clarification:'content',proposedActions:'clarify'}],
 ['اجتماع',{intent:'event',clarification:'date',proposedActions:'clarify'}],['ابغى',{intent:'clarify',clarification:'content',proposedActions:'clarify'}],
 ['موعد اليوم الساعه ٠٠',{intent:'event',date:'today',time:'00:00'}],['موعد اليوم الساعه 23:59',{intent:'event',date:'today',time:'23:59'}],
 ['شراء مقاضي اليوم', {date:'today'}]
];
const make=(s:string,patch:Partial<Interpretation>={}):Interpretation=>({intent:'task',title:clean(s),category:'personal',date:'none',time:'',period:'none',priority:'normal',clarification:'none',proposedActions:'create',...patch});
let passed=0;const failures:{name:string;error:string}[]=[];
async function test(name:string,fn:()=>unknown){try{await fn();passed++}catch(e){failures.push({name,error:String(e)})}}
for(const [text,patch] of fixtures)await test(text,async()=>{assert.ok(safeInput(text));const draft=make(text,patch);let calls=0;const repo=new MemoryRepository();const service=new CommandService(repo,()=>now,async input=>{calls++;assert.equal(input,text);return draft});const r=await service.submitSmart(text);assert.equal(calls,1);assert.equal(r.results[0].status,draft.clarification==='none'?'completed':'clarification');if(draft.clarification==='none'){assert.ok(r.store.records.length);assert.equal((await repo.load()).records.length,r.store.records.length);assert.equal(r.store.records[0].time,draft.time||undefined)}else assert.equal(r.store.records.length,0)});
await test('shopping errand stays a personal task even if Gemini labels it grocery',async()=>{const text='شراء مقاضي بكرا قبل الظهر';const svc=new CommandService(new MemoryRepository(),()=>now,async()=>make(text,{intent:'grocery',date:'tomorrow',period:'beforeNoon'}));const r=await svc.submitSmart(text);assert.equal(r.store.records.length,1);assert.equal(r.store.records[0].kind,'task');assert.equal(r.store.records[0].category,'personal');assert.equal(r.store.records[0].time,undefined)});
for(const text of ['راتبي 15000','رصيدي 3000','رقم الحساب SA123456789','ادفع فاتورة الكهرباء','شراء مقاضي بكرا بمبلغ 200','اجتماع بكرا\nراتبي 10000','بيض وكندر حسابي بالبنك','شراء مقاضي بكرا 100','اجتماع مع خالد','اجتماع بكرا \u200bراتب','اكتب ملاحظة رمز البنك 1234','شراء اسهم بكرا'])await test('privacy: '+text,async()=>{let calls=0;const svc=new CommandService(new MemoryRepository(),()=>now,async()=>{calls++;throw Error('must not send')});await svc.submitSmart(text);assert.equal(calls,0)});
await test('single-field time and date clarification saves same command without second provider call',async()=>{let calls=0;const text=fixtures[0][0];const svc=new CommandService(new MemoryRepository(),()=>now,async()=>{calls++;return make(text,fixtures[0][1])});const r=await svc.submitSmart(text);const s=await svc.answer(r.results[0].id,'22:00');assert.equal(s.commands.length,1);assert.equal(s.records[0].date,'2026-10-30');assert.equal(s.records[0].time,'22:00');assert.equal(calls,1)});
await test('morning date clarification preserves period and never sends email',async()=>{const [text,patch]=fixtures[1];const svc=new CommandService(new MemoryRepository(),()=>now,async()=>make(text,patch));const r=await svc.submitSmart(text);const s=await svc.answer(r.results[0].id,'2026-11-02');assert.equal(s.records[0].kind,'task');assert.equal(s.records[0].time,undefined);assert.match(s.records[0].content!,/الصباح/);assert.equal(s.records[0].category,'work')});
await test('two commands and duplicate suppression',async()=>{let calls=0;const svc=new CommandService(new MemoryRepository(),()=>now,async text=>{calls++;return make(text)});const r=await svc.submitSmart('تنظيف البيت\nقراءة كتاب');assert.equal(r.store.records.length,2);const again=await svc.submitSmart('تنظيف البيت');assert.equal(again.store.records.length,2);assert.equal(calls,2)});
for(const error of ['HTTP 429','quota exhausted','timeout','HTTP 503','offline'])await test('preserves failed input: '+error,async()=>{let calls=0;const repo=new MemoryRepository();const svc=new CommandService(repo,()=>now,async()=>{calls++;assert.equal((await repo.load()).commands[0].status,'failed');throw Error(error)});const r=await svc.submitSmart('تنظيف البيت');assert.equal(calls,1);assert.equal(r.results[0].status,'failed');assert.equal((await repo.load()).commands[0].original,'تنظيف البيت');assert.equal(r.store.records.length,0)});
for(const patch of [{date:'tomorrow'},{time:'12:00'},{amountMinor:123},{title:'عنوان مخترع'},{intent:'transaction'},{proposedActions:'sendEmail'},{clarification:'none',period:'morning'}])await test('reject invalid model '+JSON.stringify(patch),()=>assert.throws(()=>validateInterpretation({...make('تنظيف البيت'),...patch},'تنظيف البيت')));
await test('before-noon never becomes exact noon',async()=>{const [text,patch]=fixtures[2];assert.throws(()=>validateInterpretation(make(text,{...patch,time:'12:00'}),text))});
await test('unauthenticated Worker requests cannot reach provider',async()=>{const r=await worker.fetch(new Request('https://ai.example.com/interpret',{method:'POST'}),{} as never);assert.equal(r.status,401)});
await test('atomic rate limit persists across limiter instances',async()=>{const data=new Map();const storage={async transaction<T>(fn:(s:typeof storage)=>Promise<T>):Promise<T>{return fn(storage)},async get<T>(key:string){return data.get(key) as T},async put(key:string,value:unknown){data.set(key,value)}};for(let i=0;i<6;i++)assert.equal((await new UserLimits({storage}).fetch()).status,200);assert.equal((await new UserLimits({storage}).fetch()).status,429)});
await test('Worker signed Access JWT, validated provider JSON, quota/outage/malformed and privacy boundaries',async()=>{
 const keys=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
 const jwk={...await crypto.subtle.exportKey('jwk',keys.publicKey),kid:'test-only'};
 const env={APP_ORIGIN:'https://lifeflow23.github.io',ACCESS_TEAM:'test-only.cloudflareaccess.com',ACCESS_AUD:'aud',ALLOWED_EMAIL:'test@example.invalid',GEMINI_MODEL:'gemini-test-flash-lite',FREE_TIER_CONFIRMED:'true',GEMINI_API_KEY:'fake-test-key',LIMITS:{idFromName:(s:string)=>s,get:()=>({fetch:async()=>new Response('{}')})}};
 const claims={iss:'https://'+env.ACCESS_TEAM,aud:['aud'],sub:'single-user',email:env.ALLOWED_EMAIL,iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+600};
 const sign=async(c:unknown)=>{const payload=Buffer.from(JSON.stringify({alg:'RS256',kid:'test-only'})).toString('base64url')+'.'+Buffer.from(JSON.stringify(c)).toString('base64url');return payload+'.'+Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',keys.privateKey,new TextEncoder().encode(payload))).toString('base64url')};
 const token=await sign(claims);const originalFetch=globalThis.fetch;let calls=0;let providerStatus=200;let malformed=false;
 globalThis.fetch=async(input,init)=>{const url=String(input);if(url.endsWith('/certs'))return Response.json({keys:[jwk]});calls++;assert.equal(new Headers(init?.headers).get('x-goog-api-key'),'fake-test-key');assert.ok(!url.includes('fake-test-key'));return Response.json(providerStatus===200?{candidates:[{finishReason:'STOP',content:{parts:[{text:malformed?'broken':JSON.stringify(make('تنظيف البيت'))}]}}]}:{error:'test'}, {status:providerStatus})};
 const request=(input='تنظيف البيت',jwt=token,origin='https://ai.example.com')=>new Request('https://ai.example.com/interpret',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','Cf-Access-Jwt-Assertion':jwt},body:JSON.stringify({input})});
 try{
  let r=await worker.fetch(request(),env);assert.equal(r.status,200);assert.equal((await r.json()).result.intent,'task');assert.equal(calls,1);
  for(const bad of [{...claims,email:'attacker@example.invalid'},{...claims,exp:0},{...claims,aud:['wrong']},{...claims,iss:'https://evil.invalid'}])assert.equal((await worker.fetch(request('تنظيف البيت',await sign(bad)),env)).status,401);
  assert.equal(calls,1);assert.equal((await worker.fetch(request('تنظيف البيت',token,'https://evil.invalid'),env)).status,403);
  assert.equal((await worker.fetch(request('راتبي 20000'),env)).status,400);assert.equal(calls,1);
  assert.equal((await worker.fetch(request(),{...env,FREE_TIER_CONFIRMED:'false'})).status,503);assert.equal(calls,1);
  providerStatus=429;assert.equal((await worker.fetch(request(),env)).status,429);assert.equal(calls,2);
  providerStatus=503;assert.equal((await worker.fetch(request(),env)).status,502);assert.equal(calls,3);
  providerStatus=200;malformed=true;assert.equal((await worker.fetch(request(),env)).status,502);assert.equal(calls,4);
 }finally{globalThis.fetch=originalFetch}
});
fs.writeFileSync('qa/ai-test-results.json',JSON.stringify({passed,failed:failures.length,saudiCommandFixtures:fixtures.length,mode:'mocked provider; live Gemini NOT tested',failures},null,2));console.log({passed,failed:failures.length,failures});if(failures.length)process.exitCode=1;
