import {IndexedRepository} from '../src/local/storage';
import {CommandService} from '../src/local/executor';
import type {Interpretation} from '../src/local/ai-contract';
const repo=new IndexedRepository('lifeflow-gemini-isolated-persistence-20261029');
const title='شراء مقاضي بكرا قبل الظهر';
const draft:Interpretation={intent:'task',title,category:'personal',date:'tomorrow',time:'',period:'beforeNoon',priority:'normal',clarification:'none',proposedActions:'create'};
try{let store=await repo.load();if(!store.records.length){const svc=new CommandService(repo,()=>new Date('2026-10-29T22:00:00+03:00'),async()=>draft);store=(await svc.submitSmart(title)).store;sessionStorage.setItem('lifeflow-ai-test-record',store.records[0].id);document.querySelector('#result')!.textContent='SAVED: '+JSON.stringify(store.records[0])}else{const r=store.records[0];if(r.id!==sessionStorage.getItem('lifeflow-ai-test-record')||r.title!==title||r.date!=='2026-10-30'||r.time!==undefined||r.content!=='الفترة المطلوبة: قبل الظهر')throw Error('persistence mismatch');document.querySelector('#result')!.textContent='PASS AFTER RELOAD: '+JSON.stringify(r)}}catch(e){document.querySelector('#result')!.textContent='FAIL: '+e}
