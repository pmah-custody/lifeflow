import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createLifeFlowServer} from '../server/server.mjs';
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'lifeflow-sync-'));
const token='isolated-test-key';let app=createLifeFlowServer({directory,token});
const listen=async()=>{await new Promise(r=>app.server.listen(0,'127.0.0.1',r));return `http://127.0.0.1:${app.server.address().port}`};let base=await listen();
const call=(method='GET',body,key=token,extra={})=>fetch(base+'/api/state',{method,headers:{authorization:`Bearer ${key}`,'content-type':'application/json',...extra},body:body?JSON.stringify(body):undefined});
let checks=0;const check=(actual,expected)=>{assert.deepEqual(actual,expected);checks++};
try{
 check((await call('GET',null,'wrong')).status,401);
 check((await call('GET',null,token,{Origin:'http://untrusted.invalid'})).status,403);
 const first=await(await call()).json();check(first.revision,0);
 const second=structuredClone(first);first.records.push({id:'shared-task',kind:'task',title:'اختبار جهازين',status:'open',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
 check((await call('PUT',{store:first,expectedRevision:0})).status,200);
 check((await(await call()).json()).records[0].title,'اختبار جهازين');
 check((await call('PUT',{store:second,expectedRevision:0})).status,409);
 check((await call('PUT',{store:{bad:true},expectedRevision:1})).status,400);
 const next=await(await call()).json();next.records[0].status='done';check((await call('PUT',{store:next,expectedRevision:1})).status,200);
 check((await(await call()).json()).records[0].status,'done');
 check(fs.existsSync(path.join(directory,'state.json.previous')),true);
 await new Promise(r=>app.server.close(r));app=createLifeFlowServer({directory,token});base=await listen();
 check((await(await call()).json()).revision,2);check((await(await call()).json()).records[0].status,'done');
 console.log(`${checks} shared-server checks passed (authentication, cross-origin rejection, two clients, conflict, validation, disk restart).`);
}finally{await new Promise(r=>app.server.close(r))}
