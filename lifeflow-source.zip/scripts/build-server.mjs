import {createRequire} from 'node:module';
import {realpathSync} from 'node:fs';
const require=createRequire(realpathSync(new URL('../node_modules/vite/package.json',import.meta.url)));
await require('esbuild').build({entryPoints:['server/domain.ts'],bundle:true,platform:'node',format:'esm',outfile:'server/domain.generated.mjs'});
