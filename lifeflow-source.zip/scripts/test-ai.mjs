import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {realpathSync} from 'node:fs';
const require=createRequire(realpathSync(new URL('../node_modules/vite/package.json',import.meta.url)));
await require('esbuild').build({entryPoints:['tests/ai-suite.ts'],bundle:true,packages:'external',platform:'node',target:'node22',format:'esm',outfile:'qa/ai-suite.mjs'});
const result=spawnSync(process.execPath,['qa/ai-suite.mjs'],{stdio:'inherit'});process.exitCode=result.status??1;
