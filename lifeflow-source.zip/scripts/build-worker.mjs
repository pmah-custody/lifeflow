import {createRequire} from 'node:module';
import {realpathSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const require=createRequire(realpathSync(new URL('../node_modules/vite/package.json',import.meta.url)));
const esbuild=require('esbuild');
await esbuild.build({entryPoints:['tests/password-auth.ts'],bundle:true,platform:'node',format:'esm',target:'node22',outfile:'qa/password-auth-test.mjs'});
const r=spawnSync(process.execPath,['qa/password-auth-test.mjs'],{stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);
await esbuild.build({entryPoints:['worker/src/index.ts'],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:'worker/build/worker.js'});
