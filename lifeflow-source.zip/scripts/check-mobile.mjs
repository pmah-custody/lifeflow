import fs from 'node:fs';
import assert from 'node:assert/strict';
const base=process.env.LIFEFLOW_BASE_PATH||'/';
const html=fs.readFileSync('dist/index.html','utf8');
const manifest=JSON.parse(fs.readFileSync('dist/manifest.webmanifest','utf8'));
assert.equal(manifest.start_url,'./');assert.equal(manifest.scope,'./');assert.equal(manifest.display,'standalone');
for(const icon of manifest.icons){assert.ok(!icon.src.startsWith('/'));assert.ok(fs.existsSync('dist/'+icon.src))}
for(const match of html.matchAll(/(?:src|href)="([^"]+)"/g)){if(match[1].startsWith('http'))continue;assert.ok(match[1].startsWith(base),`wrong asset base: ${match[1]}`)}
const sw=fs.readFileSync('dist/sw.js','utf8');assert.ok(sw.includes('index.html'));assert.ok(sw.includes('woff2'));assert.ok(sw.includes('aurora.jpg'));
const connection=fs.readFileSync('src/Connection.tsx','utf8');assert.ok(!connection.includes('fetch('));assert.ok(!connection.includes('SharedRepository'));
const bundle=fs.readdirSync('dist/assets').filter(f=>f.endsWith('.js')).map(f=>fs.readFileSync('dist/assets/'+f,'utf8')).join('\n');assert.ok(!bundle.includes('/api/state'));assert.ok(!bundle.includes('/api/info'));assert.ok(!bundle.includes('lifeflow-pairing'));
console.log('Mobile packaging passed: standalone manifest, base paths, cached assets, no computer API dependency.');
