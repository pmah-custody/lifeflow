import {emptyStore,type Store} from './model';
import {migrate,validateStore} from './validation';
export interface Repository {load():Promise<Store>;save(next:Store,expectedRevision:number):Promise<Store>}
export class IndexedRepository implements Repository {
 constructor(private name='lifeflow-local-v2'){}
 private open(){return new Promise<IDBDatabase>((resolve,reject)=>{const request=indexedDB.open(this.name,2);request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('state'))request.result.createObjectStore('state')};request.onerror=()=>reject(request.error);request.onblocked=()=>reject(Error('أغلق تبويبات LifeFlow القديمة لإكمال ترقية التخزين'));request.onsuccess=()=>{request.result.onversionchange=()=>request.result.close();resolve(request.result)}})}
 async load(){const db=await this.open();try{return await new Promise<Store>((resolve,reject)=>{const tx=db.transaction('state','readonly');const request=tx.objectStore('state').get('root');request.onsuccess=()=>{try{resolve(request.result===undefined?emptyStore():migrate(request.result))}catch(e){reject(e)}};request.onerror=()=>reject(request.error)})}finally{db.close()}}
 async save(next:Store,expectedRevision:number){validateStore(next);const db=await this.open();const saved=structuredClone(next);saved.revision=expectedRevision+1;try{await new Promise<void>((resolve,reject)=>{const tx=db.transaction('state','readwrite');const store=tx.objectStore('state');const read=store.get('root');let failure:Error|undefined;read.onsuccess=()=>{const revision=read.result?.revision??0;if(revision!==expectedRevision){failure=Error('تغيّرت البيانات في تبويب آخر. حدّث البيانات ثم أعد المحاولة.');tx.abort();return}store.put(saved,'root')};tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||Error('تعذر الحفظ'));tx.onabort=()=>reject(failure||tx.error||Error('ألغي الحفظ'))});const verified=await this.load();if(verified.revision<saved.revision)throw Error('تعذر التحقق من الحفظ');return verified}finally{db.close()}}
}
export class MemoryRepository implements Repository {
 data=emptyStore();fail=false;
 async load(){return structuredClone(this.data)}
 async save(next:Store,expected:number){if(this.fail)throw Error('Injected storage failure');if(this.data.revision!==expected)throw Error('Concurrent update');validateStore(next);this.data=structuredClone({...next,revision:expected+1});return this.load()}
}

