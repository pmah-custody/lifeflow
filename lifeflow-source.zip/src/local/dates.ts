import {normalize} from './normalize';
import type {RecordItem,Recurrence} from './model';
export const DAY=86400000;
export const riyadhDate=(now:Date)=>new Date(now.getTime()+3*3600000).toISOString().slice(0,10);
export const atRiyadh=(date:string,time='00:00')=>new Date(`${date}T${time}:00+03:00`);
export function validDate(s:string){return /^\d{4}-\d{2}-\d{2}$/.test(s)&&!isNaN(Date.parse(s+'T00:00:00Z'))&&new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s}
export function addDays(date:string,n:number){return new Date(Date.parse(date+'T00:00:00Z')+n*DAY).toISOString().slice(0,10)}
export const weekdays=['الاحد','الاثنين','الثلاثاء','الاربعاء','الخميس','الجمعه','السبت'];
export function resolveDate(input:string,now:Date,override:{date?:string;time?:string}={}):{date?:string;time?:string;reason?:string;field?:'date'|'time';recurrence?:Recurrence}{
 const t=normalize(input);let date:string|undefined=override.date,time:string|undefined=override.time;
 const iso=t.match(/\b(\d{4}-\d{2}-\d{2})\b/);if(iso&&!override.date){if(!validDate(iso[1]))return {reason:'التاريخ غير صالح. اكتب تاريخ ميلادي بصيغة YYYY-MM-DD.',field:'date'};date=iso[1]}
 if(!override.date){if(/بعد (?:ساعتين|ساعه|\d+ ساعات?)/.test(t)){const hours=/ساعتين/.test(t)?2:/بعد ساعه/.test(t)?1:Number(t.match(/بعد (\d+)/)?.[1]);const dt=new Date(now.getTime()+hours*3600000);date=riyadhDate(dt);time=new Date(dt.getTime()+10800000).toISOString().slice(11,16)}
 else if(/بعد بكره/.test(t))date=addDays(riyadhDate(now),2);else if(/بكره/.test(t))date=addDays(riyadhDate(now),1);else if(/اليوم/.test(t))date=riyadhDate(now);else if(/امس/.test(t))date=addDays(riyadhDate(now),-1);}
 if(/الاسبوع الجاي|الشهر الجاي|ديسمبر|يناير|فبراير|مارس|ابريل|مايو|يونيو|يوليو|اغسطس|سبتمبر|اكتوبر|نوفمبر|\d{1,2}[\/]\d{1,2}/.test(t)&&!date)return {reason:'وش التاريخ الميلادي بالضبط، شامل السنة؟',field:'date'};
 const day=weekdays.findIndex(d=>t.includes(d)||t.includes('كل '+d.replace(/^ال/,'')));if(day>=0&&!date){const current=new Date(riyadhDate(now)+'T00:00:00Z').getUTCDay();const offset=(day-current+7)%7;if(offset===0&&!/القادم|الجاي|كل /.test(t))return {reason:'تقصد اليوم أو الأسبوع القادم؟ اختر تاريخًا محددًا.',field:'date'};date=addDays(riyadhDate(now),offset||7)}
 const clock=t.match(/الساعه\s*(\d{1,2})(?::(\d{2}))?\s*(صباحا?|ص|مساء|مساءا|م|العصر|الظهر|الليل)?/);if(clock&&!override.time){let h=+clock[1],m=+(clock[2]||0);if(h>23||m>59)return {reason:'اكتب وقتًا صحيحًا بصيغة 24 ساعة، مثل 17:30.',field:'time'};if(!clock[3]&&h>=1&&h<=12)return {reason:'صباح أو مساء؟ اكتب الوقت بصيغة 24 ساعة، مثل 08:00 أو 20:00.',field:'time'};if(clock[3]&&h>12)return {reason:'الساعة متناقضة مع الفترة. اكتب الوقت بصيغة 24 ساعة.',field:'time'};if(clock[3]&&/مساء|العصر|الظهر|الليل|^م$/.test(clock[3]))h=h%12+12;else if(clock[3])h%=12;time=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`}
 else if(/العصر|المغرب|الصباح|المساء/.test(t)&&!time)return {reason:'الساعة كم بالضبط؟ مثال: 17:00.',field:'time'};
 let recurrence:Recurrence|undefined;if(/كل يوم/.test(t))recurrence={unit:'day',interval:1};else if(/كل (?:6|ست) شهور/.test(t))recurrence={unit:'month',interval:6};else if(/كل شهر/.test(t))recurrence={unit:'month',interval:1};else if(/كل /.test(t)&&day>=0)recurrence={unit:'week',interval:1};
 if(recurrence&&!date)date=riyadhDate(now);
 if(recurrence&&/لمده شهر/.test(t)&&date){const dt=new Date(date+'T00:00:00Z');const desired=dt.getUTCDate();dt.setUTCDate(1);dt.setUTCMonth(dt.getUTCMonth()+1);const last=new Date(Date.UTC(dt.getUTCFullYear(),dt.getUTCMonth()+1,0)).getUTCDate();dt.setUTCDate(Math.min(desired,last));recurrence.until=addDays(dt.toISOString().slice(0,10),-1)}
 if(/كل |لمده /.test(t)&&!recurrence)return {reason:'التكرار غير واضح. حدد يوميًا أو أسبوعيًا أو شهريًا.',field:'date'};
 return {date,time,recurrence};
}
export function nextOccurrence(date:string,r:Recurrence){if(r.unit!=='month')return addDays(date,r.interval*(r.unit==='week'?7:1));const d=new Date(date+'T00:00:00Z');const day=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+r.interval);d.setUTCDate(Math.min(day,new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate()));return d.toISOString().slice(0,10)}
export function occursOn(r:RecordItem,date:string){if(!r.date)return false;if(!r.recurrence)return r.date===date;let d=r.date;for(let i=0;i<5000&&d<=date;i++){if(r.recurrence.until&&d>r.recurrence.until)return false;if(d===date)return true;d=nextOccurrence(d,r.recurrence)}return false}
export type Deadline = Partial<RecordItem>;
export function countdown(r:Deadline,now:Date){
 if(r.status==='done')return 'مكتملة';
 if(r.status==='cancelled')return 'ملغاة';
 if(!r.date)return '';
 if(!r.time){const days=Math.round((Date.parse(r.date)-Date.parse(riyadhDate(now)))/DAY);return days===0?'اليوم':days>0?`باقي ${days} يوم`:`متأخرة ${-days} يوم`}
 const delta=atRiyadh(r.date,r.time).getTime()-now.getTime();
 if(delta===0)return 'حان الموعد';
 const duration=Math.abs(delta),prefix=delta<0?'متأخرة':'باقي';
 if(duration>DAY){const days=Math.floor(duration/DAY);return `${prefix} ${days} يوم${duration%DAY?' وجزء من يوم':''}`}
 const minutes=Math.ceil(duration/60000);
 return `${prefix} ${String(Math.floor(minutes/60)).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}`;
}
export function recordState(r:RecordItem,now:Date){return r.status==='done'?'completed':r.status==='cancelled'?'cancelled':overdue(r,now)?'overdue':r.urgent?'urgent':r.category==='work'?'work':'life'}
export function recordStateLabel(r:RecordItem,now:Date){const state=recordState(r,now);return ({completed:'مكتملة',cancelled:'ملغاة',overdue:'متأخرة',urgent:'عاجل',work:'مفتوحة',life:'مفتوحة'})[state]}
export function overdue(r:RecordItem,now:Date){return r.status!=='done'&&r.status!=='cancelled'&&!!r.date&&(r.time?atRiyadh(r.date,r.time)<now:r.date<riyadhDate(now))}
export function salaryDate(now:Date){const local=new Date(now.getTime()+10800000);for(let add=0;add<3;add++){const d=new Date(Date.UTC(local.getUTCFullYear(),local.getUTCMonth()+add,27));if(d.getUTCDay()===5)d.setUTCDate(26);else if(d.getUTCDay()===6)d.setUTCDate(28);const target=atRiyadh(d.toISOString().slice(0,10),'02:00');if(target>now)return target}throw Error('Salary date resolution failed')}
export function salaryDays(now:Date){return Math.max(1,Math.ceil((salaryDate(now).getTime()-now.getTime())/DAY))}
export function reminderDue(r:RecordItem,now:Date,quietStart:number,quietEnd:number,ack?:string){if(!r.date||!r.time||r.status==='done'||r.status==='cancelled'||ack)return false;const h=new Date(now.getTime()+10800000).getUTCHours();if(quietStart!==quietEnd&&(quietStart>quietEnd?h>=quietStart||h<quietEnd:h>=quietStart&&h<quietEnd))return false;const delta=atRiyadh(r.date,r.time).getTime()-now.getTime();return delta<= (r.urgent?60:30)*60000&&delta>=-DAY}

