// One shared clock for the entire app, including return from background / bfcache.
export function startAppClock(emit:(now:Date)=>void,host:EventTarget=window,visibility:EventTarget=document,now:()=>Date=()=>new Date(),schedule:(fn:()=>void)=>()=>void=fn=>{const id=setInterval(fn,1000);return()=>clearInterval(id)}){
 const refresh=()=>emit(now());refresh();const stop=schedule(refresh);
 host.addEventListener('focus',refresh);host.addEventListener('pageshow',refresh);visibility.addEventListener('visibilitychange',refresh);
 return()=>{stop();host.removeEventListener('focus',refresh);host.removeEventListener('pageshow',refresh);visibility.removeEventListener('visibilitychange',refresh)};
}
