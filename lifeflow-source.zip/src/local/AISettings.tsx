import {useState} from 'react';
import {connectAI,disconnectAI,aiAvailable} from './ai';
export function AISettings(){
 const [url,setUrl]=useState('');const [status,setStatus]=useState(()=>aiAvailable()?'نافذة تسجيل الدخول مفتوحة؛ نجاح Gemini يتأكد عند معالجة الطلب وحفظه':'غير متصل — يلزم إعداد الخادم وتسجيل الدخول');
 return <section className="settings-section"><h3>Gemini</h3><p>يحفظ التطبيق بياناتك محليًا. يرسل الأوامر غير المالية التي تجتاز حدود الخصوصية فقط. النصوص غير المعروفة تبقى محلية. قد تستخدم Google مدخلات الطبقة المجانية لتحسين منتجاتها.</p><label>رابط خادم LifeFlow الآمن<input type="url" dir="ltr" placeholder="https://ai.example.com" value={url} onChange={e=>setUrl(e.target.value)}/></label><button className="primary" onClick={()=>{try{connectAI(url);setStatus('أكمل تسجيل الدخول في النافذة، ثم ارجع وأرسل طلبًا. فتح النافذة لا يؤكد اتصال Gemini.')}catch(e){setStatus((e as Error).message)}}}>تسجيل الدخول</button><button className="text-btn" onClick={()=>{disconnectAI();setStatus('تم فصل Gemini؛ القواعد المحلية فعالة')}}>فصل</button><p role="status">{status}</p></section>;
}
