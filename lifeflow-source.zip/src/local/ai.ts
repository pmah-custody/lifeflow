import {clean,safeInput,validateInterpretation,type Interpretation} from './ai-contract';
import {addDays,riyadhDate,validDate} from './dates';
import type {Context,Proposal} from './model';
import {splitGroceries,productCategory} from './normalize';
export type Interpreter=(text:string)=>Promise<Interpretation>;
export const periodLabels={none:'',morning:'الصباح',beforeNoon:'قبل الظهر',evening:'المساء',afternoon:'العصر'};
export function aiProposal(v:Interpretation,original:string,now:Date,context:Context={}):Proposal{
 const date=context.date||(v.date==='none'?undefined:addDays(riyadhDate(now),({today:0,tomorrow:1,afterTomorrow:2} as const)[v.date]));
 const time=context.time||v.time||undefined;
 const field=v.clarification==='content'?'content':v.clarification==='time'&&!context.time?'time':(!date&&(v.period!=='none'||v.intent==='event'||time))?'date':undefined;
 if(field)return {outcome:'clarify',reason:'فهمنا الطلب ونحتاج توضيحًا واحدًا',actions:[],clarification:{field,question:field==='time'?'صباح أو مساء؟ اكتب الوقت بصيغة 24 ساعة، مثل 10:00 أو 22:00.':field==='date'?'أي تاريخ تقصد؟ اكتب YYYY-MM-DD.':'الطلب منفي أو غير واضح. عدّل النص قبل حفظه.'}};
 if(date&&!validDate(date)||time&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('تاريخ أو وقت غير صالح');
 if(v.intent==='clarify')throw Error('عدّل النص قبل حفظه');
 // A shopping errand is a task. Only named products become grocery records.
 const kind=v.intent==='grocery'&&/(^| )(شراء|اشتري|تسوق|مقاضي|بقاله)( |$)/.test(clean(original))?'task':v.intent;
 const titles=kind==='grocery'?splitGroceries(original):[original];
 return {outcome:'ready',reason:'فهم Gemini مع تحقق محلي',actions:titles.map((title,i)=>({type:'create',key:'ai'+i,record:{kind:kind as 'task'|'event'|'grocery',title,category:kind==='grocery'?productCategory(title)||'غير مصنف':v.category,status:'open',urgent:v.priority==='urgent',...(date?{date}:{}),...(time?{time}:{}),...(v.period!=='none'?{content:'الفترة المطلوبة: '+periodLabels[v.period]}:{})}}))};
}
// The authenticated popup makes same-origin requests: no cross-site cookies or stored bearer tokens.
let popup:Window|null=null;let origin='';
export function connectAI(url:string){const u=new URL(url);if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('أدخل أصل HTTPS لخادم LifeFlow فقط');origin=u.origin;popup=window.open(origin+'/bridge','lifeflow-ai','popup,width=480,height=650');if(!popup)throw Error('اسمح بفتح نافذة تسجيل الدخول');}
export function disconnectAI(){popup?.close();popup=null;origin=''}
export function aiAvailable(){return !!popup&&!popup.closed}
export const interpret:Interpreter=async text=>{
 const safe=safeInput(text);if(!safe)throw Error('النص بقي محليًا لحماية الخصوصية');if(!aiAvailable())throw Error('سجّل دخول خادم Gemini من الإعدادات');
 const id=crypto.randomUUID();const source=popup;const expected=origin;
 return new Promise((resolve,reject)=>{const done=()=>{clearTimeout(timer);window.removeEventListener('message',receive)};const receive=(e:MessageEvent)=>{if(e.origin!==expected||e.source!==source||e.data?.id!==id)return;done();try{if(e.data.error)throw Error(e.data.error);resolve(validateInterpretation(e.data.result,safe))}catch(err){reject(err)}};const timer=setTimeout(()=>{done();reject(Error('انتهت مهلة Gemini؛ الطلب محفوظ محليًا'))},20000);window.addEventListener('message',receive);source!.postMessage({type:'lifeflow-interpret',id,input:safe},expected)});
};
