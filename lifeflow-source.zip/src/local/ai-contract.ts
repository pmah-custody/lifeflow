// Shared fail-closed boundary: never send arbitrary prose, databases, or history.
export const clean=(s:string)=>s.normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/\s+/g,' ').trim();
const vocabulary=new Set(clean('اجتماع موعد زوم تيمز مكالمة اتصال ارسال ارسل ايميل بريد لشؤون شؤون الموظفين العمل عمل تقرير مراجعة راجع تجهيز جهز اكتب كتابة شراء اشتري مقاضي تسوق بقالة بيض وكندر كندر حليب خبز رز سكر قهوة ماء تفاح موز دجاج زيارة الطبيب النادي مشي تمرين قراءة كتاب تنظيف البيت المنزل شخصي مهمة مهمه اضف ضيف حط سجل ذكرني لازم و بكرا بكره غدا اليوم بعد قبل الظهر الصباح صباح صباحا المساء مساء مساءا العصر الليل الساعة الساعه عاجل ضروري لا مو لاتضيف لا تضيف لاترسل لا ترسل بدون الغاء الغ لا اريد ابغى ابي ودي عندي مع في على الى للموظفين للبيت للعمل').split(' '));
export function safeInput(input:string):string|null{
 if(typeof input!=='string'||input.length>500||!input.trim())return null;
 const t=clean(input);
 // Closed vocabulary, not a blacklist. Unknown names, amounts, free prose and identifiers stay local.
 const words=t.split(' ');if(words.some((w,i)=>!vocabulary.has(w)&&!(w.startsWith('و')&&vocabulary.has(w.slice(1)))&&!(words[i-1]==='الساعه'&&/^(?:[01]?\d|2[0-3])(?::[0-5]\d)?$/.test(w))))return null;
 return t;
}
export type Interpretation={intent:'task'|'event'|'grocery'|'clarify';title:string;category:'work'|'personal';date:'none'|'today'|'tomorrow'|'afterTomorrow';time:string;period:'none'|'morning'|'beforeNoon'|'evening'|'afternoon';priority:'normal'|'urgent';clarification:'none'|'date'|'time'|'content';proposedActions:'create'|'clarify'};
export const responseSchema={type:'object',additionalProperties:false,required:['intent','title','category','date','time','period','priority','clarification','proposedActions'],properties:{intent:{type:'string',enum:['task','event','grocery','clarify']},title:{type:'string'},category:{type:'string',enum:['work','personal']},date:{type:'string',enum:['none','today','tomorrow','afterTomorrow']},time:{type:'string'},period:{type:'string',enum:['none','morning','beforeNoon','evening','afternoon']},priority:{type:'string',enum:['normal','urgent']},clarification:{type:'string',enum:['none','date','time','content']},proposedActions:{type:'string',enum:['create','clarify']}}};
export function validateInterpretation(value:unknown,input:string):Interpretation{
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('استجابة Gemini غير صالحة');
 const v=value as Interpretation;const keys=Object.keys(responseSchema.properties);
 if(Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))throw Error('حقول استجابة غير صالحة');
 for(const [k,rule] of Object.entries(responseSchema.properties)){const x=(v as unknown as Record<string,unknown>)[k];if(typeof x!=='string'||('enum' in rule&&!rule.enum.includes(x)))throw Error('قيمة استجابة غير صالحة')}
 const t=safeInput(input);if(!t||v.title!==t)throw Error('عنوان غير مستند إلى الإدخال');
 const date=/بعد (بكرا|بكره|غدا)/.test(t)?'afterTomorrow':/بكرا|بكره|غدا/.test(t)?'tomorrow':/اليوم/.test(t)?'today':'none';
 const period=/قبل الظهر/.test(t)?'beforeNoon':/الصباح|صباح/.test(t)?'morning':/المساء|مساء|الليل/.test(t)?'evening':/العصر/.test(t)?'afternoon':'none';
 if(v.date!==date||v.period!==period||v.priority!==( /عاجل|ضروري/.test(t)?'urgent':'normal'))throw Error('تاريخ أو فترة أو أولوية غير مستندة إلى الإدخال');
 const clock=t.match(/الساعه (\d{1,2})(?::(\d{2}))?/);let time='';let ambiguous=false;
 if(clock){let h=+clock[1];ambiguous=h>=1&&h<=12&&period==='none';if(!ambiguous){if(h<=12&&['evening','afternoon'].includes(period))h=h%12+12;else if(h===12&&period==='morning')h=0;time=String(h).padStart(2,'0')+':'+(clock[2]||'00')}}
 if(v.time!==time)throw Error('وقت مخترع أو غامض');
 const negated=/(^| )(لا|مو|لاتضيف|لاترسل|الغاء|الغ|بدون)( |$)/.test(t);
 const required=negated||v.intent==='clarify'?'content':ambiguous?'time':(period!=='none'||v.intent==='event'||!!clock)&&date==='none'?'date':'none';
 if(v.clarification!==required||v.proposedActions!==(required==='none'?'create':'clarify'))throw Error('توضيح مطلوب قبل التنفيذ');
 return v;
}
