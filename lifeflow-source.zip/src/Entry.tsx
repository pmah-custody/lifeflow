import {useState} from 'react';
import DemoApp from './App';
import LocalApp from './Connection';
export default function Entry(){const [demo,setDemo]=useState(false);return demo?<><div className="demo-isolation"><span>معاينة Phase 0 · بيانات خيالية منفصلة لا تُحفظ</span><button onClick={()=>setDemo(false)}>رجوع لبياناتي المحلية</button></div><DemoApp/></>:<LocalApp showDemo={()=>setDemo(true)}/>}
