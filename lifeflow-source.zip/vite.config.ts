import {defineConfig,loadEnv} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import {VitePWA} from 'vite-plugin-pwa';
export default defineConfig(({mode})=>{
 const base=loadEnv(mode,'.','').LIFEFLOW_BASE_PATH||'/';
 return {base,plugins:[react(),tailwindcss(),VitePWA({
  registerType:'prompt',injectRegister:null,
  includeAssets:['assets/*.jpg','icon.svg','icon-192.png','icon-512.png'],
  manifest:{id:'./',name:'LifeFlow AI — مساحة أهدأ ليومك',short_name:'LifeFlow AI',lang:'ar',dir:'rtl',theme_color:'#090f1f',background_color:'#090f1f',display:'standalone',start_url:'./',scope:'./',icons:[{src:'icon-192.png',sizes:'192x192',type:'image/png'},{src:'icon-512.png',sizes:'512x512',type:'image/png'},{src:'icon.svg',sizes:'any',type:'image/svg+xml',purpose:'any'}]},
  workbox:{globPatterns:['**/*.{js,css,html,svg,png,jpg,woff2}'],maximumFileSizeToCacheInBytes:4000000,cleanupOutdatedCaches:true,navigateFallback:'index.html',navigateFallbackDenylist:[/\/api\//],ignoreURLParametersMatching:[/^utm_/,/^fbclid$/,/^qa$/]}
 })]};
});
